const puppeteer = require('puppeteer');
const fs = require('fs').promises;

const scrape = async () =>
{
    const browser = await puppeteer.launch({ headless: false } );
    const page = await browser.newPage();
    await page.goto('https://ogr.kocaeli.edu.tr/koubs/Bologna/');
    for(i = 1 ; i<=26 ; i++)
    {
        await page.click('xpath=//*[@id="listMenuRoot"]/li[5]');
        await page.click('xpath=//*[@id="center"]/table[2]/tbody/tr[2]/td[2]/strong/a[4]');
        await page.waitForXPath('//*[@id="red"]/li[14]/div');
        await page.click('xpath=//*[@id="red"]/li[14]/div');
        await page.waitForXPath('//*[@id="red"]/li[14]/ul/li['+ i +']/a');
        await page.click('xpath=//*[@id="red"]/li[14]/ul/li['+ i +']/a');
        await page.waitForXPath('/html/body/table/tbody/tr/td[1]/div[5]/ul/li[4]');
        await page.click('xpath=/html/body/table/tbody/tr/td[1]/div[5]/ul/li[4]');
        await page.waitForXPath('//*[@id="center"]/table[2]/tbody/tr[2]/td[2]/table[1]');
        const table_data = await page.evaluate(() => 
        {
            const table = document.evaluate('//*[@id="center"]/table[2]/tbody/tr[2]/td[2]/table[1]', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            const rows = table.querySelectorAll('tr');

            const data = [];
            rows.forEach((row) => {
              const columns = row.querySelectorAll('td');
              const rowData = Array.from(columns).map(column => column.innerText);
              data.push(rowData);
            });
            return data;
        });
        const isim_data = await page.$eval('xpath=/html/body/table/tbody/tr/td[2]/table[2]/tbody/tr[2]/td[2]/font/b/div/text()[2]'
        , element =>{ return element.textContent.trim();});
        const jsonData = JSON.stringify(table_data, null, 2);
        await fs.writeFile(isim_data + '.json', jsonData, 'utf-8');
    }
    browser.close();
}

scrape();